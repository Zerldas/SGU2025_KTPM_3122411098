#include<iostream>

using namespace std;

/*Dễ thấ test case lần lượt là: > 10 và <= 10*/

int f1(int x) {
    if (x > 10)
        return 2 * x; 
    else
        return -x;
} 

int main() {
    int x;
    cin >> x;
    cout << f1(x) << endl;
    return 0;
}